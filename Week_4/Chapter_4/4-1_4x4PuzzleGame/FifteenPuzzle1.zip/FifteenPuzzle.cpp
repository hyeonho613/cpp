#include "Ranking.h"
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <termios.h>
#include <time.h>
#include <string.h>
#include <sys/select.h>  // select()
#include <fcntl.h>       // fcntl()

#define DIM  4

enum Direction { Left = 75, Right = 77, Up = 72, Down = 80 };
static int DirKey[4] = { Left, Right, Up, Down };
static int map[DIM][DIM];
static int x, y;
static int nMove;
static time_t tStart, tGameStart;

static void setNonBlockingInput(bool enable) {
    struct termios ttystate;
    tcgetattr(STDIN_FILENO, &ttystate);
    if (enable) {
        ttystate.c_lflag &= ~(ICANON | ECHO);
        ttystate.c_cc[VMIN] = 0;
        ttystate.c_cc[VTIME] = 0;
    } else {
        ttystate.c_lflag |= ICANON | ECHO;
    }
    tcsetattr(STDIN_FILENO, TCSANOW, &ttystate);
}

static int kbhit() {
    struct timeval tv = {0L, 0L};
    fd_set fds;
    FD_ZERO(&fds);
    FD_SET(STDIN_FILENO, &fds);
    return select(STDIN_FILENO+1, &fds, NULL, NULL, &tv);
}

static int getch_nonblock() {
    if (kbhit()) return getchar();
    else return 0;
}

static void init() {
    for (int i = 0; i < DIM * DIM - 1; i++)
        map[i / DIM][i % DIM] = i + 1;
    map[DIM - 1][DIM - 1] = 0;
    x = DIM - 1;
    y = DIM - 1;
    srand(time(NULL));
    nMove = 0;
}

static void display() {
    system("clear");
    printf("\tFifteen Puzzle\n\t");
    printf("--------------\n\t");
    for (int r = 0; r < DIM; r++) {
        for (int c = 0; c < DIM; c++) {
            if (map[r][c] > 0)
                printf("%3d", map[r][c]);
            else 
                printf("   ");
        }
        printf("\n\t");
    }
    printf("--------------\n\t");
    time_t tNow = time(NULL);
    int seconds = (int)(tNow - tGameStart);
    printf("\n\t이동 횟수:%6d\n\t경과 시간:%6d초\n\n", nMove, seconds);
}

static bool move(int dir) {
    if (dir == Right && x > 0) {
        map[y][x] = map[y][x - 1];
        map[y][--x] = 0;
    }
    else if (dir == Left && x < DIM - 1) {
        map[y][x] = map[y][x + 1];
        map[y][++x] = 0;
    }
    else if (dir == Up && y < DIM - 1) {
        map[y][x] = map[y + 1][x];
        map[++y][x] = 0;
    }
    else if (dir == Down && y > 0) {
        map[y][x] = map[y - 1][x];
        map[--y][x] = 0;
    }
    else 
        return false;

    nMove++;
    return true;
}

static void shuffle(int nShuffle) {
    for (int i = 0; i < nShuffle; i++) {
        int key = DirKey[rand() % 4];
        if (!move(key)) { 
            i--; 
            continue; 
        }
        display();
        usleep(50000);
    }
}

static bool isDone() {
    for (int r = 0; r < DIM; r++) {
        for (int c = 0; c < DIM; c++) {
            if (map[r][c] != r * DIM + c + 1)
                return (r == DIM - 1) && (c == DIM - 1);
        }
    }
    return true;
}

int playFifteenPuzzle() {
    init();
    display();
    printRanking();
    printf("\n 계속하려면 아무 키나 누르세요...");
    getchar();

    shuffle(100);
    printf("\n 게임을 시작합니다...");
    getchar();

    nMove = 0;
    tGameStart = time(NULL); // 기준 시간 0 설정
    setNonBlockingInput(true);

    while (!isDone()) {
        int key = getch_nonblock();
        if (key == 27) {
            if (kbhit() && getchar() == 91) {
                if (kbhit()) {
                    int ch3 = getchar();
                    int dir = 0;
                    if (ch3 == 'A') dir = Up;
                    if (ch3 == 'B') dir = Down;
                    if (ch3 == 'C') dir = Right;
                    if (ch3 == 'D') dir = Left;
                    if (dir) move(dir);
                }
            }
        }
        display();
        usleep(200000);
    }

    setNonBlockingInput(false);

    time_t tNow = time(NULL);
    int seconds = (int)(tNow - tGameStart);
    return addRanking(nMove, seconds);
}
